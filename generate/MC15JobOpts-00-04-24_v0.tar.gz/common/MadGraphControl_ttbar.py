from MadGraphControl.MadGraphUtils import *
import fileinput
import shutil
import subprocess
import os

# DSID list of ttbar samples
tt_nonallhad = [410225]
tt_dilepton  = [410226]
tt_allhad    = [410227]
thisDSID     = runArgs.runNumber

# --------------------------------------------------------------
#  Some global production settings
# --------------------------------------------------------------
# Make some excess of events
nevents=1.1*runArgs.maxEvents #10000
mode=0

lhaid=260000
pdfmin=260001
pdfmax=260100

reweight_scale = '.true.'
reweight_PDF   = '.true.'
pdflabel='lhapdf'
maxjetflavor=5
parton_shower='PYTHIA8'
muR_over_ref  = 1.0
muF1_over_ref = 1.0
muF2_over_ref = 1.0
dyn_scale = '0'    # user-defined scale -> Dominic's definition of mt+1/2*(pt^2+ptx^2)
lhe_version=3

# --------------------------------------------------------------
#  Setting up the process
# --------------------------------------------------------------

proc = 'generate p p > t t~ [QCD]'
name = ""
wdecay = ""
nLeptons = -99

# Number of leptons
if thisDSID in tt_allhad:
    nLeptons = 0
    evgenConfig.description += ', allhad'
    name = "ttbarNLO4fl_allhad"
    wdecay = "decay t > w+ b, w+ > j j \n decay t~ > w- b~, w- > j j \n"
elif thisDSID in tt_nonallhad:
    nLeptons = -1
    # Adjust the number of events to account of filter efficiency
    nevents = nevents*2.0
    evgenConfig.description += ', non-allhad'
    name = "ttbarNLO4fl_nonallhad"
    wdecay = "decay t > w+ b, w+ > all all \n decay t~ > w- b~, w- > all all \n"
elif thisDSID in tt_dilepton:
    nLeptons = 2
    evgenConfig.description += ', dilepton'
    name = "ttbarNLO4fl_dilepton"
    wdecay = "define lv = e+ mu+ ta+ ve vm vt e- mu- ta- ve~ vm~ vt~ \n decay t > w+ b, w+ > lv lv \n decay t~ > w- b~, w- > lv lv \n"
else:
    raise RuntimeError("DSID %i is not recoginsed for this control files."%(thisDSID))

stringy = 'madgraph.'+str(runArgs.runNumber)+'.MadGraph_'+str(name)

# Proc card writing
fcard = open('proc_card_mg5.dat','w')
fcard.write("""
import model loop_sm
define p = g u c d s u~ c~ d~ s~
define j = g u c d s u~ c~ d~ s~
"""+proc+"""
output -f
""")
fcard.close()

# --------------------------------------------------------------
#  Check the beam energy
# --------------------------------------------------------------

beamEnergy=-999
if hasattr(runArgs,'ecmEnergy'):
    beamEnergy = runArgs.ecmEnergy / 2.
else:
    raise RuntimeError("No center of mass energy found.")

# --------------------------------------------------------------
#  Start building the cards
# --------------------------------------------------------------
process_dir = new_process()

# Cook the setscales file for the user defined dynamical scale
fileN = process_dir+'/SubProcesses/setscales.f'
mark  = '      elseif(dynamical_scale_choice.eq.0) then'
rmLines = ['ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc',
           'cc      USER-DEFINED SCALE: ENTER YOUR CODE HERE                                 cc',
           'cc      to use this code you must set                                            cc',
           'cc                 dynamical_scale_choice = 0                                    cc',
           'cc      in the run_card (run_card.dat)                                           cc',
           'write(*,*) "User-defined scale not set"',
           'stop 1',
           'temp_scale_id=\'User-defined dynamical scale\' ! use a meaningful string',
           'tmp = 0',
           'cc      USER-DEFINED SCALE: END OF USER CODE                                     cc'
           ]

for line in fileinput.input(fileN, inplace=1):
    toKeep = True
    for rmLine in rmLines:
        if line.find(rmLine) >= 0:
           toKeep = False
           break
    if toKeep:
        print line,
    if line.startswith(mark):
        print """
c         Q^2= mt^2 + 0.5*(pt^2+ptbar^2)
          xm2=dot(pp(0,3),pp(0,3))
          tmp=sqrt(xm2+0.5*(pt(pp(0,3))**2+pt(pp(0,4))**2))
          temp_scale_id='mt**2 + 0.5*(pt**2+ptbar**2)'
              """

# Decay with MadSpin
madspin_card_loc='madspin_card.dat'
mscard = open(madspin_card_loc,'w')
mscard.write("""#************************************************************
#*                        MadSpin                           *
#*                                                          *
#*    P. Artoisenet, R. Frederix, R. Rietkerk, O. Mattelaer *
#*                                                          *
#*    Part of the MadGraph5_aMC@NLO Framework:              *
#*    The MadGraph5_aMC@NLO Development Team - Find us at   *
#*    https://server06.fynu.ucl.ac.be/projects/madgraph     *
#*                                                          *
#************************************************************
set max_weight_ps_point 400  # number of PS to estimate the maximum for each event
set seed %i
define j = g u c d s b u~ c~ d~ s~ b~
%s
launch
"""%(runArgs.randomSeed, wdecay))
mscard.close()

# --------------------------------------------------------------
#  Additional run card options
# --------------------------------------------------------------
run_card_extras = { 'lhaid'         : lhaid,
                    'pdlabel'       : "'"+pdflabel+"'",
                    'parton_shower' : parton_shower,
                    'maxjetflavor'  : maxjetflavor,
                    'reweight_scale': reweight_scale,
                    'reweight_PDF'  : reweight_PDF,
                    'PDF_set_min'   : pdfmin,
                    'PDF_set_max'   : pdfmax,
                    'muR_over_ref'  : muR_over_ref,
                    'muF1_over_ref' : muF1_over_ref,
                    'muF2_over_ref' : muF2_over_ref,
                    'dynamical_scale_choice' : dyn_scale,
                    'jetalgo'   : '-1',  # use anti-kT jet algorithm
                    'jetradius' : '0.4', # set jet cone size of 0.4
                    'ptj'       : '0.1', # minimum jet pT
                    }

# Run card
build_run_card(
      run_card_old = get_default_runcard(proc_dir=process_dir),
      run_card_new = 'run_card.dat',
      nevts = nevents,
      rand_seed = runArgs.randomSeed,
      beamEnergy = beamEnergy,
      xqcut=0.,
      extras = run_card_extras
      )

# Param card
paramNameToCopy      = 'aMcAtNlo_param_card_tt.dat'
paramNameDestination = 'param_card.dat'
paramcard            = subprocess.Popen(['get_files','-data',paramNameToCopy])
paramcard.wait()
if not os.access(paramNameToCopy,os.R_OK):
    raise RuntimeError("ERROR: Could not get %s"%(paramNameToCopy))
shutil.copy(paramNameToCopy,paramNameDestination)

# Print the cards
print_cards()

# --------------------------------------------------------------                                                                                                                    # Set everything up and run
# --------------------------------------------------------------
generate(run_card_loc='run_card.dat',
         param_card_loc='param_card.dat',
         madspin_card_loc='madspin_card.dat',
         mode=mode,
         proc_dir=process_dir,
         run_name=name,
         required_accuracy=0.001)

arrange_output(run_name=name,
               proc_dir=process_dir,
               outputDS=stringy+'._00001.events.tar.gz',
               lhe_version=lhe_version)


# --------------------------------------------------------------
# Run Pythia 8 Showering
# --------------------------------------------------------------
evgenConfig.generators    += ["aMcAtNlo", "Pythia8"]
evgenConfig.description    = 'MG5_aMC@NLO+Pythia8+EvtGen '+name+' OTF, A14 NNPDF 2.3 LO, ME NNPDF 3.0 NLO, using scale sqrt(sum_i mT(i)**2/2)), for i = top quarks'
evgenConfig.keywords      += [ 'SM', 'top']
evgenConfig.contact        = [ 'ian.connelly@cern.ch' ]
evgenConfig.inputfilecheck = stringy
runArgs.inputGeneratorFile = stringy+'._00001.events.tar.gz'

include("MC15JobOptions/Pythia8_A14_NNPDF23LO_EvtGen_Common.py")
include("MC15JobOptions/Pythia8_aMcAtNlo.py")

# --------------------------------------------------------------
# Apply TTbarWToLeptonFilter
# --------------------------------------------------------------
# Only truely needed for non-all hadronic decays

include("MC15JobOptions/TTbarWToLeptonFilter.py")
filtSeq.TTbarWToLeptonFilter.NumLeptons = nLeptons
filtSeq.TTbarWToLeptonFilter.Ptcut = 0.0
