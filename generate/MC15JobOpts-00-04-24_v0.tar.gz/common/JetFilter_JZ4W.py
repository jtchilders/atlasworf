## Truth jet filter config for JZ4W
include("MC15JobOptions/JetFilter_JZ4.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
