## Truth jet filter config for JZ9
include("MC15JobOptions/JetFilter_JZX_Fragment.py")
JZSlice(9)

