include("MC15JobOptions/Pythia_Base_Fragment.py")
genSeq.Pythia.Tune_Name = "PYTUNE_370"
evgenConfig.tune = "Perugia2012"
