## Truth jet filter config for JZ4
include("MC15JobOptions/JetFilter_JZXR04_Fragment.py")
JZSlice(4)


