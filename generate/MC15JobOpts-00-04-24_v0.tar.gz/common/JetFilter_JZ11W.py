## Truth jet filter config for JZ11W
include("MC15JobOptions/JetFilter_JZ11.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
