
include("MC15JobOptions/Pythia_Perugia2012_Common.py")

evgenConfig.generators += ["Alpgen", "Pythia"]

genSeq.Pythia.PythiaCommand += ["pyinit user alpgen",
                                "pydat1 parj 90 20000.",
                                "pydat3 mdcy 15 1 0",
                                "pypars mstp 143 1"
                                ]
