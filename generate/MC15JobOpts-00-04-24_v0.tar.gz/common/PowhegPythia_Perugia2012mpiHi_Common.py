## POWHEG+PYTHIA config for the Perugia 2012mpiHi (CTEQ6L1 PDF) UE tune
include("MC15JobOptions/Pythia_Perugia2012mpiHi_Common.py")

include('MC15JobOptions/Pythia_Powheg.py')

