## Truth jet filter config for JZ1W
include("MC15JobOptions/JetFilter_JZ1.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
