## Herwig7 config for the H7-UE-MMHT tune series with CT10 NLO ME PDF and EvtGen
include("MC15JobOptions/Herwig7_H7UE_MMHT2014lo68cl_CT10_Common.py")
include("MC15JobOptions/Herwig7_EvtGen.py")
