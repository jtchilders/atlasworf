## Sherpa config with CT10 PDF
include("MC15JobOptions/Sherpa_Base_Fragment.py")

## CT10 is Sherpa's default PDF/tune, thus no need to set anything up
evgenConfig.tune = "CT10"
