include ( 'MC15JobOptions/MadGraphControl_SimplifiedModelPreInclude.py' )

def MassToFloat(s):
  if "p" in s:
    return float(s.replace("p", "."))
  return float(s)

splitConfig = runArgs.jobConfig[0].rstrip('.py').split('_')
decaytype='N2_ZN1'

#C1/N2 degenerate
masses['1000023'] = MassToFloat(splitConfig[4])
masses['1000024'] = (MassToFloat(splitConfig[4])+MassToFloat(splitConfig[5]))/2.
masses['1000022'] = MassToFloat(splitConfig[5])

gentype = splitConfig[3]

process = '''
define c1 = x1+ x1-
define w = w+ w-
generate p p > n2 n1
add process p p > n2 c1
add process p p > c1 c1
add process p p > c1 n1
'''

evgenLog.info('p p > c1n1/c1n2/c1c1/n2/n1 productions. ')
#--------------------------------------------------------------
# Algorithms Private Options
#--------------------------------------------------------------
pythia = genSeq.Pythia8

evgenConfig.contact  = [ "ruo-yu.shang@cern.ch" ]
evgenConfig.keywords += ['chargino', 'neutralino']
evgenConfig.description = 'SUSY Simplified Model with chargino/neutrlino production and decays via Z with MadGraph/Pythia8'

#--------------------------------------------------------------
# add some filter here
#--------------------------------------------------------------

njets = 0
# Two-lepton filter
if '1L' in runArgs.jobConfig[0]:
    evt_multiplier = 20
    if masses['1000023']-masses['1000022']<10: evt_multiplier = 30
    include('MC15JobOptions/MultiLeptonFilter.py')
    MultiLeptonFilter = filtSeq.MultiLeptonFilter
    MultiLeptonFilter.Ptcut = 3000.
    MultiLeptonFilter.Etacut = 2.8
    MultiLeptonFilter.NLeptons = 1
if 'MET50' in runArgs.jobConfig[0]:
    include ( 'MC15JobOptions/MissingEtFilter.py' )
    filtSeq.MissingEtFilter.METCut = 50*GeV

include('MC15JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')
pythia.Commands += ["23:mMin = 0.2"]
pythia.Commands += ["24:mMin = 0.2"]
pythia.Commands += ["-24:mMin = 0.2"]
