## Example configuration for QCDTruthJetFilter setting up defaults

include("MC15JobOptions/AntiKt4TruthJets_pileup.py")
include("MC15JobOptions/AntiKt6TruthJets_pileup.py")
include("MC15JobOptions/JetFilter_Fragment.py")


