## Truth jet filter config for JZ5W
include("MC15JobOptions/JetFilter_JZ5.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
