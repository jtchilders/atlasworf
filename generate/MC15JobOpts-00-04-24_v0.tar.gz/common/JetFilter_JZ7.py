## Truth jet filter config for JZ7
include("MC15JobOptions/JetFilter_JZX_Fragment.py")
JZSlice(7)

