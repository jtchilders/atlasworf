## Truth jet filter config for JZ0W
include("MC15JobOptions/JetFilter_JZ0.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
