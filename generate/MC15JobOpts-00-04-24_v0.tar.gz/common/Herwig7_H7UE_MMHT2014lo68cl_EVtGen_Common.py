## Herwig7 config for the H7-UE-MMHT tune series with MMHT2014 LO PDF and EvtGen
include("MC15JobOptions/Herwig7_H7UE_MMHT2014lo68cl_Common.py")
include("MC15JobOptions/Herwig7_EvtGen.py")
