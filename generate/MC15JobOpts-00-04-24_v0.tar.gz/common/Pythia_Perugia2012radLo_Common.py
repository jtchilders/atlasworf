## PYTHIA 6 config with Perugia 2012 radLo (372)
include("MC15JobOptions/Pythia_Base_Fragment.py")
genSeq.Pythia.Tune_Name = "PYTUNE_372"
evgenConfig.tune = "Perugia2012radLo" 
