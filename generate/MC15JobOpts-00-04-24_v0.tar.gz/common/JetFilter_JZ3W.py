## Truth jet filter config for JZ3W
include("MC15JobOptions/JetFilter_JZ3.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
