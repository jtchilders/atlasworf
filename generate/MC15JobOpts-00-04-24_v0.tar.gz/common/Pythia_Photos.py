## PHOTOS config for PYTHIA

## Disable native QED FSR
assert hasattr(genSeq, "Pythia")
genSeq.Pythia.PythiaCommand += ["pydat1 parj 90 20000"]

## Enable PHOTOS
include("MC15JobOptions/nonStandard/Photos_Fragment.py")
