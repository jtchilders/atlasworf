## Truth jet filter config for JZ12W
include("MC15JobOptions/JetFilter_JZ12.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
