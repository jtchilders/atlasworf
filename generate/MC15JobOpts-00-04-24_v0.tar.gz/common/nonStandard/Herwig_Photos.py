assert hasattr(genSeq, "Herwig")

## Enable PHOTOS
include("MC15JobOptions/nonStandard/Photos_Fragment.py")
