## Enable Powheg LHEF reading with Herwig/Jimmy
include("MC15JobOptions/nonStandard/Herwig_LHEF.py")
evgenConfig.generators += ["Powheg"]