## Configure Herwig/Jimmy for LHEF input
assert hasattr(genSeq, "Herwig")
genSeq.Herwig.HerwigCommand += ["iproc lhef"]