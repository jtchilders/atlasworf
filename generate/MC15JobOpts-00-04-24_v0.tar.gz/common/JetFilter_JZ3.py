## Truth jet filter config for JZ3
include("MC15JobOptions/JetFilter_JZX_Fragment.py")
JZSlice(3)

