# MG+PYTHIA config for the Perugia 2012 radHi (with alphaS(pT/2)) (CTEQ6L1 PDF) UE tune
include("MC15JobOptions/Pythia_Perugia2012radHi_Common.py")
include('MC15JobOptions/Pythia_MadGraph.py')
