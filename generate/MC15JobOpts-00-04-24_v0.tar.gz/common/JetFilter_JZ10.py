## Truth jet filter config for JZ10
include("MC15JobOptions/JetFilter_JZX_Fragment.py")
JZSlice(10)

