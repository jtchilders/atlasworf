include("MC15JobOptions/Pythia_Base_Fragment.py")
genSeq.Pythia.Tune_Name = "PYTUNE_374"
evgenConfig.tune = "Perugia2012loCR"
