
if runArgs.trfSubstepName == 'afterburn':
  evgenConfig.generators += ["MadGraph"]

include('MC15JobOptions/Pythia_EvtGen.py')
