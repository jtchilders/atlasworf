## POWHEG+PYTHIA config for the Perugia 2012loCR (CTEQ6L1 PDF) UE tune
include("MC15JobOptions/Pythia_Perugia2012loCR_Common.py")

include('MC15JobOptions/Pythia_Powheg.py')

