include ( 'MC15JobOptions/MadGraphControl_SimplifiedModelPreInclude.py' )

masses['1000006'] = float(runArgs.jobConfig[0].split('_')[4])
masses['1000022'] = float(runArgs.jobConfig[0].split('_')[5].split('.')[0])
if masses['1000022']<0.5: masses['1000022']=0.5
gentype = str(runArgs.jobConfig[0].split('_')[2])
decaytype = str(runArgs.jobConfig[0].split('_')[3])
process = '''
generate p p > t1 t1~ $ go susylq susylq~ b1 b2 t2 b1~ b2~ t2~ @1
add process p p > t1 t1~ j $ go susylq susylq~ b1 b2 t2 b1~ b2~ t2~ @2
add process p p > t1 t1~ j j $ go susylq susylq~ b1 b2 t2 b1~ b2~ t2~ @3
'''
njets = 2
evgenLog.info('Registered generation of stop pair production, stop to t+LSP; grid point '+str(runArgs.runNumber)+' decoded into mass point ' + str(masses['1000006']))

jobConfigParts = runArgs.jobConfig[0].split("_")

if '1L20andMET0_100' in "%s_%s" % (jobConfigParts[-2], jobConfigParts[-1]):

    evgenLog.info('1lepton and MET 0_100 filter is applied')
    include ( 'MC15JobOptions/LeptonFilter.py' )
    filtSeq.LeptonFilter.Ptcut  = 20*GeV
    filtSeq.LeptonFilter.Etacut = 2.8 
    include('MC15JobOptions/MissingEtFilter.py')
    filtSeq.MissingEtFilter.METCut = 0*GeV
    filtSeq.MissingEtFilterUpperCut.METCut = 100*GeV	

    filtSeq.Expression = "LeptonFilter and (MissingEtFilter and not MissingEtFilterUpperCut)"

    evt_multiplier = 100.

if '1L20andMET50_100' in "%s_%s" % (jobConfigParts[-2], jobConfigParts[-1]):

    evgenLog.info('1lepton and MET 50_100 filter is applied')
    include ( 'MC15JobOptions/LeptonFilter.py' )
    filtSeq.LeptonFilter.Ptcut  = 20*GeV
    filtSeq.LeptonFilter.Etacut = 2.8 
    include('MC15JobOptions/MissingEtFilter.py')
    filtSeq.MissingEtFilter.METCut = 50*GeV
    filtSeq.MissingEtFilterUpperCut.METCut = 100*GeV	

    filtSeq.Expression = "LeptonFilter and (MissingEtFilter and not MissingEtFilterUpperCut)"

    evt_multiplier = 100.


elif 'MET100' in runArgs.jobConfig[0].split("_")[-1]:
    evgenLog.info('MET100 filter is applied')
    include ( 'MC15JobOptions/MissingEtFilter.py' )

    filtSeq.MissingEtFilter.METCut = 100*GeV

    evt_multiplier = 100.

evgenConfig.contact  = [ "takashi.yamanaka@cern.ch" ]
evgenConfig.keywords += ['simplifiedModel', 'stop']
evgenConfig.description = 'stop direct pair production, st->t+LSP in simplified model, m_stop = %s GeV, m_N1 = %s GeV'%(masses['1000006'],masses['1000022'])

include ( 'MC15JobOptions/MadGraphControl_SimplifiedModelPostInclude.py' )

if njets>0:
    genSeq.Pythia8.Commands += ["Merging:Process = pp>{t1,1000006}{t1~,-1000006}"]
