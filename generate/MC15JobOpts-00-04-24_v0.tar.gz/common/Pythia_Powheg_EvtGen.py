
if runArgs.trfSubstepName == 'afterburn':
  evgenConfig.generators += ["Powheg"]

include('MC15JobOptions/Pythia_EvtGen.py')
