from Herwig7_i.Herwig7_iConf import Herwig7
genSeq += Herwig7()
evgenConfig.generators += ["Herwig7"]

from Herwig7_i import config as hw
genSeq.Herwig7.Commands += hw.atlas_parameter_cmds().splitlines()
