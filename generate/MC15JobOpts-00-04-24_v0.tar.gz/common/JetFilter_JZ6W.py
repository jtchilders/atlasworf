## Truth jet filter config for JZ6W
include("MC15JobOptions/JetFilter_JZ6.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
