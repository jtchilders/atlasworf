
assert hasattr(genSeq, "Pythia")
# Read external Les Houches event file
genSeq.Pythia.PythiaCommand += ["pyinit user lhef"]
evgenConfig.generators += ["Powheg"]
