## Truth jet filter config for JZ10W
include("MC15JobOptions/JetFilter_JZ10.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
