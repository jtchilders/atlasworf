## Truth jet filter config for JZ8W
include("MC15JobOptions/JetFilter_JZ8.py")
include("MC15JobOptions/JetFilter_JZXW_Fragment.py")
